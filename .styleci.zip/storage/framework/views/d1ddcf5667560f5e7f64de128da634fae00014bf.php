

<?php $__env->startSection('content'); ?>

<div class="px-48">
    <?php if(sizeof($pets) > 0): ?>
        <form class="flex flex-row" action="" method="GET">
            <div class="flex flex-grow pr-5">
                <label for="pet-search" class="sr-only">Search</label>
                <div class="relative w-full">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <svg class="h-5 w-5 text-blue-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                        <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" />
                    </svg>
                    </div>
                    <input id="pet-search" name="pet-search" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" placeholder="Search" type="search">
                </div>
            </div>
            <div class="flex">
                <input class="bg-blue-500 text-white px-6 py-2 rounded-md cursor-pointer hover:bg-blue-700 duration-200" type="submit" value="Search">
            </div>
        </form>

        <div class="flex flex-wrap mt-5 justify-center">
            <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col bg-white rounded-lg shadow-md duration-150 w-60 overflow-hidden hover:shadow-xl m-2 pb-2">
                    <a href="<?php echo e(route('pet.show', ['pet' => $pet])); ?>" class="flex flex-col w-60">
                        <div class="h-60 w-60">
                            <img class="h-60 w-full object-cover" src="<?php echo e($PUBLIC_FOLDER_URL); ?>/pet/<?php echo e($pet->image); ?>" alt="">
                        </div>
                        <div class="flex-1 bg-white  flex flex-col justify-between">
                            <div class="flex-1 flex flex-col space-y-2 items-center">
                                <p class="text-xl py-4 font-semibold text-gray-900 text-center whitespace-normal">
                                    <?php echo e($pet->name); ?>

                                </p>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-data')): ?>
                                        <button class="bg-blue-500 text-white px-4 py-2 w-3/4 rounded " type="submit"><a
                                                href="<?php echo e(route('pet.edit', ['pet' => $pet])); ?>">Update Pet</a></button>
                                    <form method="post" action="<?php echo e(route('pet.destroy', ['pet' => $pet])); ?>" class="flex w-full justify-center items-center">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="bg-red-500 text-white px-4 py-2 w-3/4 rounded" type="submit">Delete Pet</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-8">
            <div>
                <?php echo e($pets->links()); ?>

            </div>
        </div>
    <?php else: ?>
        <div class="container h2 text-center mt-3">
            Pet is not found!
        </div>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\pet-shop\resources\views/pet-category/show.blade.php ENDPATH**/ ?>