

<?php $__env->startSection('content'); ?>
    <div class="flex flex-col justify-center items-center">
            <div class="bg-white shadow overflow-hidden sm:rounded-md flex flex-col w-3/4">
                <ul class="divide-y divide-gray-200">
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-data')): ?>
                    <a href="<?php echo e(route('transaction.show', compact('transaction'))); ?>" class="list-group-item list-group-item-action p-4 bg-light text-dark h5">Transaction at <?php echo e($transaction->created_at); ?> <br> User ID : <?php echo e($transaction->user_id); ?> <br> Username : <?php echo e($transaction->user->username); ?> </a>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e(route('transaction.show', compact('transaction'))); ?>" class="block hover:bg-gray-50 ">
                            <div class="px-4 py-4 flex items-center sm:px-6">
                                <div class="min-w-0 flex-1 sm:flex sm:items-center sm:justify-between">
                                    <div class="truncate">
                                        <div class="flex text-sm">
                                            <p class="font-medium text-indigo-600 truncate">Transaction</p>
                                        </div>
                                        <div class="mt-2 flex">
                                            <div class="flex items-center text-sm text-gray-500">
                                                <!-- Heroicon name: solid/calendar -->
                                                <svg class="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                    <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd" />
                                                </svg>
                                                <p>
                                                    On
                                                    <p>&nbsp;<?php echo e($transaction->created_at); ?></p>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </li>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\pet-shop\resources\views\transaction\index.blade.php ENDPATH**/ ?>