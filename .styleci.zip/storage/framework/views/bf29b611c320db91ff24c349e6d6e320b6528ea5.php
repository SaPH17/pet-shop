

<?php $__env->startSection('content'); ?>
    <div class="container pt-5">
        <div class="card">
            <div class="card-body">
                <div class="d-inline-flex w-100">

                    <div>
                        <img src="/asset/<?php echo e($pet->image); ?>" height="250rem">
                    </div>

                    <div class="mx-5 w-100">
                        <p class="card-title h1 mx-2 font-weight-bold">
                            <?php echo e($pet->name); ?>

                        </p>
                        <p class="card-text h5">
                            <?php echo e($pet->description); ?>

                        </p>
                        <br>
                        <p class="card-text h5">
                            Rp. <?php echo e($pet->price); ?>

                        </p>

                        <?php if(auth()->check() && auth()->user()->email != 'admin@admin.com'): ?>
                            <form action="/pet/<?php echo e($pet->id); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($pet->id); ?>" name="pet_id">
                                <input type="hidden" value="<?php echo e(auth()->user()->id); ?>" name="user_id">
                                <div class="form-group row mt-5">
                                    <label class="col-md-4 col-form-label" for="quantity">Quantity : </label>
                                    <div class="col-md-6">
                                        <input id="quantity" type="number" class="form-input" name="quantity">
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary ml-5">Add to Cart</button>
                            </form>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\pet-shop\resources\views\pet-detail.blade.php ENDPATH**/ ?>