

<?php $__env->startSection('content'); ?>
    <div class=" pt-5 flex flex-col items-center">
        <div class="card bg-white rounded-xl p-10 shadow-lg">
            <div class="card-body">
                <div class="d-inline-flex w-100">

                    <div class="mx-5 w-100">
                        <h3 class="text-lg leading-6 font-medium text-gray-900">
                            Add New Pet Category
                        </h3>
                        <p class="mt-1 mb-6 text-sm text-gray-500">
                            Input new pet category information accordingly.
                        </p>
                        <form action="<?php echo e(route('category.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label class="block text-sm font-medium text-gray-700 col-form-label" for="name">Category Name : </label>
                                <div class="col-md-6">
                                    <input id="name" type="text" class="my-4 w-full form-input <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name">

                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="block text-sm font-medium text-gray-700 col-form-label" for="image">Category Image : </label>
                                <div class="col-md-6">
                                    <input id="image" type="file" class="my-4 w-full form-input <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image">
                                </div>
                            </div>

                            <div class="form-group row">
                                <button type="submit" class="bg-blue-500 text-white px-4 py-3 w-full mt-2 rounded">Add Category</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\pet-shop\resources\views\pet-category\create.blade.php ENDPATH**/ ?>