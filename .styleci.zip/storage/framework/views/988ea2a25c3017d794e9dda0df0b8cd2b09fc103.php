

<?php $__env->startSection('content'); ?>
<main class="sm:container sm:mx-auto sm:max-w-lg sm:mt-10">
    <div class="flex">
        <div class="w-full">

            <?php if(session('resent')): ?>
            <div class="text-sm border border-t-8 rounded text-green-700 border-green-600 bg-green-100  px-3 py-4 mb-4"
                role="alert">
                <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

            </div>
            <?php endif; ?>

            <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">
                <header class="font-semibold bg-gray-200 text-gray-700 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                    <?php echo e(__('Verify Your Email Address')); ?>

                </header>

                <div class="w-full flex flex-wrap text-gray-700 leading-normal text-sm p-6 space-y-4 sm:text-base sm:space-y-6">
                    <p>
                        <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

                    </p>

                    <p>
                        <?php echo e(__('If you did not receive the email')); ?>, <a
                            class="text-blue-500 hover:text-blue-700 no-underline hover:underline cursor-pointer"
                            onclick="event.preventDefault(); document.getElementById('resend-verification-form').submit();"><?php echo e(__('click here to request another')); ?></a>.
                    </p>

                    <form id="resend-verification-form" method="POST" action="<?php echo e(route('verification.resend')); ?>"
                        class="hidden">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>

            </section>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\pet-shop\resources\views\auth\verify.blade.php ENDPATH**/ ?>