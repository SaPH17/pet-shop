

<?php $__env->startSection('content'); ?>
    <div class="flex items-center flex-col justify-center">
        <?php $__currentLoopData = $transaction->detail_transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li class="media mb-6 p-10  rounded-lg list-none flex items-center bg-white shadow-lg w-1/2">
                <div class="h-20 w-20">
                    <img src="<?php echo e(Storage::url('public/pet/' . $detail->pet->image)); ?>" class=" h-20 object-cover rounded-xl" alt="" >
                </div>
                <div class="media-body ml-3">
                    <h4 class="mt-0 mb-1 font-weight-bold"><?php echo e($detail->pet->name); ?></h4>

                    <p class="h5">
                        Rp. <?php echo e($detail->pet->price); ?>

                    </p>

                    <p class="h5">
                        Quantity : <?php echo e($detail->quantity); ?>

                    </p>

                    <p class="h5">
                        Total Price : <b>Rp. <?php echo e($detail->quantity * $detail->pet->price); ?></b>
                    </p>
                </div>
            </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\pet-shop\resources\views\transaction\show.blade.php ENDPATH**/ ?>